import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { OtpAuthComponent } from './otp-auth/otp-auth.component';
import { PatientDashbordComponent } from './patient-dashbord/patient-dashbord.component';
import { ProviderDashbordComponent } from './provider-dashbord/provider-dashbord.component';
import { RegistrationComponent } from './registration/registration.component';
import { AuthGuard } from './guard/auth.guard';
 

const routes: Routes = [{path:"register",component:RegistrationComponent},
                        {path:"login",component:LoginComponent},
                        {path:"dashbord/patient",component:PatientDashbordComponent,canActivate:[AuthGuard]},
                        {path:"dashbord/provider",component:ProviderDashbordComponent,canActivate:[AuthGuard]},
                        {path:"activeAccount",component:OtpAuthComponent},
                        {path:"",component:LoginComponent},
                         
                       
                       ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
