import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { PatientDashbordComponent } from './patient-dashbord/patient-dashbord.component';
import { ProviderDashbordComponent } from './provider-dashbord/provider-dashbord.component';
import { OtpAuthComponent } from './otp-auth/otp-auth.component';
import { DatePipe } from '@angular/common';
import { TokenInterceptor } from './interceptor/token.interceptor';
import { ImageComponent } from './image/image.component';
import { SendtextComponent } from './sendtext/sendtext.component';
 

@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    PatientDashbordComponent,
    ProviderDashbordComponent,
    OtpAuthComponent,
    ImageComponent,
    SendtextComponent,
 
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [DatePipe,{
    provide:HTTP_INTERCEPTORS,
    useClass:TokenInterceptor,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
