import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { AuthenticationService } from '../APIService/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sendtext',
  templateUrl: './sendtext.component.html',
  styleUrls: ['./sendtext.component.css']
})
export class SendtextComponent  {
  constructor(private APIAuth:AuthenticationService,private router:Router){}
  
    email_pat = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
    loginform = new FormGroup({
      f_name: new FormControl("", [Validators.required, Validators.maxLength(20)]),
      mobile: new FormControl("", [Validators.required, Validators.maxLength(13)]),
     
  
    })
  
    get loginformcontrol() {
      return this.loginform.controls;
    }
    submited:boolean=false;
    userData:any;
    loader:boolean=false;
    onSubmit(){
      this.submited=true
      
      if(this.loginform.invalid)
      {return}else{
        this.loader=true



        this.userData={
          body:this.loginform.value.f_name,
          no:this.loginform.value.mobile,
      
        }
  
  
        
      
  
  
       console.log(this.userData)
  
      //  this.APIAuth.register(this.userData).subscribe(res=>

      this.APIAuth.Sendtext(this.userData).subscribe(res=>{

        console.log(res)
      })
   
      }
  
    }
  }
  