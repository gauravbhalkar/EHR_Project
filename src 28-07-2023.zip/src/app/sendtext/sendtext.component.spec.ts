import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendtextComponent } from './sendtext.component';

describe('SendtextComponent', () => {
  let component: SendtextComponent;
  let fixture: ComponentFixture<SendtextComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SendtextComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SendtextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
