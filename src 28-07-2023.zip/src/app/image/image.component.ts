import { Component } from '@angular/core';
import { AuthenticationService } from '../APIService/authentication.service';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent {
  constructor(private Api: AuthenticationService) {

  }

  files!: File;
  onFileSelection(event: any): void {
    console.log(event)
    this.files = event.target.files[0]



  }

  uploadFile() {
    const filedata = new FormData()
    filedata.append('file', this.files)
    this.Api.upload(filedata).subscribe(res => {
      console.log(res)
    })

  }

  Downlod()
  
  {

    
  


  }
}
